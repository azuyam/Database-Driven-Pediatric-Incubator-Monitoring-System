<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Validate the patient ID from URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid patient ID.");
}

include 'db_config.php';


$patient_id = $_GET['id'];



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];

    $stmt = $conn->prepare("UPDATE Patients SET First_Name = ?, Last_Name = ? WHERE Patient_ID = ?");
    $stmt->bind_param("ssi", $first_name, $last_name, $patient_id);

    if ($stmt->execute()) {
        header("Location: manage_patients.php");
        exit();
    } else {
        echo "Error updating patient.";
    }
}

// Fetch patient details
$patient_sql = "SELECT * FROM Patients WHERE Patient_ID = ?";
$patient_stmt = $conn->prepare($patient_sql);
$patient_stmt->bind_param("i", $patient_id);
$patient_stmt->execute();
$patient_result = $patient_stmt->get_result();
$patient = $patient_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Patient</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Edit Patient</h2>
        <form method="POST">
            <label>First Name:</label>
            <input type="text" name="first_name" value="<?= htmlspecialchars($patient['First_Name']) ?>" required>

            <label>Last Name:</label>
            <input type="text" name="last_name" value="<?= htmlspecialchars($patient['Last_Name']) ?>" required>

            <button type="submit">Update</button>
        </form>
        <a href="manage_patients.php" class="back-button">Back</a>
    </div>
</body>
</html>
