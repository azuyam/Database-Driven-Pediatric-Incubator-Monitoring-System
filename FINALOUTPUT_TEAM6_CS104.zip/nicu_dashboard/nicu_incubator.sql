-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2025 at 11:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nicu_incubator`
--

-- --------------------------------------------------------

--
-- Table structure for table `incubators`
--

CREATE TABLE `incubators` (
  `Incubator_ID` int(11) NOT NULL,
  `Model` varchar(50) DEFAULT NULL,
  `Manufacturer` varchar(50) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `incubators`
--

INSERT INTO `incubators` (`Incubator_ID`, `Model`, `Manufacturer`, `Location`) VALUES
(29, 'Model A', 'MedTech', 'NICU Room 101'),
(30, 'Model B', 'PediaCorp', 'NICU Room 102'),
(31, 'Model C', 'MedTech', 'NICU Room 103');

-- --------------------------------------------------------

--
-- Table structure for table `incubator_parameters`
--

CREATE TABLE `incubator_parameters` (
  `Parameter_ID` int(11) NOT NULL,
  `Incubator_ID` int(11) DEFAULT NULL,
  `CO2_Level` decimal(5,2) DEFAULT NULL,
  `Temperature` decimal(5,2) DEFAULT NULL,
  `Humidity` decimal(5,2) DEFAULT NULL,
  `Recorded_At` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `incubator_parameters`
--

INSERT INTO `incubator_parameters` (`Parameter_ID`, `Incubator_ID`, `CO2_Level`, `Temperature`, `Humidity`, `Recorded_At`) VALUES
(46, 29, 250.00, 36.50, 65.00, '2025-04-03 08:05:42'),
(47, 30, 278.00, 36.90, 68.00, '2025-04-03 08:10:35'),
(48, 31, 247.00, 36.30, 64.00, '2025-04-05 09:12:21');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `Patient_ID` int(11) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`Patient_ID`, `First_Name`, `Last_Name`) VALUES
(14, 'Juan', 'Dela Cruz'),
(15, 'Maria', 'Makiling'),
(16, 'Pedro', 'Penduko');

-- --------------------------------------------------------

--
-- Table structure for table `patient_incubator`
--

CREATE TABLE `patient_incubator` (
  `ID` int(11) NOT NULL,
  `Patient_ID` int(11) DEFAULT NULL,
  `Incubator_ID` int(11) DEFAULT NULL,
  `Assigned_At` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_incubator`
--

INSERT INTO `patient_incubator` (`ID`, `Patient_ID`, `Incubator_ID`, `Assigned_At`) VALUES
(10, 14, 29, '2025-04-05 09:13:40');

-- --------------------------------------------------------

--
-- Table structure for table `patient_vitals`
--

CREATE TABLE `patient_vitals` (
  `Vital_ID` int(11) NOT NULL,
  `Patient_ID` int(11) DEFAULT NULL,
  `Oxygen_Level` decimal(5,2) DEFAULT NULL,
  `Weight` decimal(5,2) DEFAULT NULL,
  `Heartbeat` int(11) DEFAULT NULL,
  `Blood_pH` decimal(3,2) DEFAULT NULL,
  `Recorded_At` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_vitals`
--

INSERT INTO `patient_vitals` (`Vital_ID`, `Patient_ID`, `Oxygen_Level`, `Weight`, `Heartbeat`, `Blood_pH`, `Recorded_At`) VALUES
(2, 14, 96.60, 3.00, 135, 7.00, '2025-04-05 09:13:30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_ID` int(11) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_ID`, `First_Name`, `Last_Name`, `Password`, `Username`) VALUES
(3, 'Yam', 'Adriel', 'password123', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `incubators`
--
ALTER TABLE `incubators`
  ADD PRIMARY KEY (`Incubator_ID`);

--
-- Indexes for table `incubator_parameters`
--
ALTER TABLE `incubator_parameters`
  ADD PRIMARY KEY (`Parameter_ID`),
  ADD KEY `idx_incubator_id` (`Incubator_ID`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`Patient_ID`);

--
-- Indexes for table `patient_incubator`
--
ALTER TABLE `patient_incubator`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `unique_patient_incubator` (`Patient_ID`,`Incubator_ID`),
  ADD KEY `idx_incubator_id` (`Incubator_ID`),
  ADD KEY `idx_assigned_at` (`Assigned_At`);

--
-- Indexes for table `patient_vitals`
--
ALTER TABLE `patient_vitals`
  ADD PRIMARY KEY (`Vital_ID`),
  ADD KEY `idx_patient_id` (`Patient_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD KEY `idx_user_id` (`User_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `incubators`
--
ALTER TABLE `incubators`
  MODIFY `Incubator_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `incubator_parameters`
--
ALTER TABLE `incubator_parameters`
  MODIFY `Parameter_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `Patient_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `patient_incubator`
--
ALTER TABLE `patient_incubator`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `patient_vitals`
--
ALTER TABLE `patient_vitals`
  MODIFY `Vital_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `incubator_parameters`
--
ALTER TABLE `incubator_parameters`
  ADD CONSTRAINT `incubator_parameters_ibfk_1` FOREIGN KEY (`Incubator_ID`) REFERENCES `incubators` (`Incubator_ID`) ON DELETE CASCADE;

--
-- Constraints for table `patient_incubator`
--
ALTER TABLE `patient_incubator`
  ADD CONSTRAINT `patient_incubator_ibfk_1` FOREIGN KEY (`Patient_ID`) REFERENCES `patients` (`Patient_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `patient_incubator_ibfk_2` FOREIGN KEY (`Incubator_ID`) REFERENCES `incubators` (`Incubator_ID`) ON DELETE CASCADE;

--
-- Constraints for table `patient_vitals`
--
ALTER TABLE `patient_vitals`
  ADD CONSTRAINT `patient_vitals_ibfk_1` FOREIGN KEY (`Patient_ID`) REFERENCES `patients` (`Patient_ID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
