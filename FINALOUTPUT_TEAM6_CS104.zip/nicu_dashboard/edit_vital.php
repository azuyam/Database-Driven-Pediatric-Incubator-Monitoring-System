<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_config.php';

$vital_id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $oxygen_level = $_POST['oxygen_level'];
    $weight = $_POST['weight'];
    $heartbeat = $_POST['heartbeat'];
    $blood_ph = $_POST['blood_ph'];

    $stmt = $conn->prepare("UPDATE Patient_Vitals SET Oxygen_Level = ?, Weight = ?, Heartbeat = ?, Blood_pH = ? WHERE Vital_ID = ?");
    $stmt->bind_param("ididi", $oxygen_level, $weight, $heartbeat, $blood_ph, $vital_id);

    if ($stmt->execute()) {
        header("Location: manage_vitals.php");
        exit();
    } else {
        echo "Error updating vital record.";
    }
}

// Fetch vital details
/* $vital_sql = "SELECT * FROM Patient_Vitals WHERE Vital_ID = ?";
$vital_stmt = $conn->prepare($vital_sql);
$vital_stmt->bind_param("i", $vital_id);
$vital_stmt->execute();
$vital_result = $vital_stmt->get_result();
$vital = $vital_result->fetch_assoc(); */

// Fetch patient vitals
$vitals_sql = "SELECT p.First_Name, p.Last_Name, v.Oxygen_Level, v.Weight, v.Heartbeat, v.Blood_pH, v.Recorded_At 
               FROM Patients p
               JOIN Patient_Vitals v ON p.Patient_ID = v.Patient_ID
               ORDER BY v.Recorded_At DESC
               LIMIT 5";
$vitals_result = $conn->query($vitals_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Vital Record</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Edit Vital Record</h2>
        <form method="POST">
            <label>Oxygen Level (%):</label>
            <input type="number" step="0.1" name="oxygen_level" value="<?= htmlspecialchars($vital['Oxygen_Level']) ?>" required>

            <label>Weight (kg):</label>
            <input type="number" step="0.1" name="weight" value="<?= htmlspecialchars($vital['Weight']) ?>" required>

            <label>Heartbeat (BPM):</label>
            <input type="number" name="heartbeat" value="<?= htmlspecialchars($vital['Heartbeat']) ?>" required>

            <label>Blood pH:</label>
            <input type="number" step="0.01" name="blood_ph" value="<?= htmlspecialchars($vital['Blood_pH'])  ?>" required>

            <button type="submit">Update</button>
        </form>
        <a href="manage_vitals.php" class="back-button">Back</a>
    </div>
</body>
</html>
