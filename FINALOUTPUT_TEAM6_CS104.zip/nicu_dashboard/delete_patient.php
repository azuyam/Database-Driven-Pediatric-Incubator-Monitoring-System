<?php
session_start();
include 'db_config.php';

if (!isset($_GET['id'])) {
    header("Location: manage_patients.php");
    exit();
}

$patient_id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM Patients WHERE Patient_ID = ?");
$stmt->bind_param("i", $patient_id);

if ($stmt->execute()) {
    header("Location: manage_patients.php");
    exit();
} else {
    echo "Error deleting patient.";
}
?>
