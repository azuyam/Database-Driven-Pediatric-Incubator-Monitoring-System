<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_config.php';

// Fetch patient vitals along with incubator assignments
$vitals_sql = "
    SELECT p.Patient_ID, p.First_Name, p.Last_Name, 
           v.Oxygen_Level, v.Weight, v.Heartbeat, v.Blood_pH, v.Recorded_At,
           i.Incubator_ID, i.Model, i.Location
    FROM Patients p
    LEFT JOIN (
        SELECT v1.*
        FROM Patient_Vitals v1
        INNER JOIN (
            SELECT Patient_ID, MAX(Recorded_At) AS Latest_Record
            FROM Patient_Vitals
            GROUP BY Patient_ID
        ) v2 ON v1.Patient_ID = v2.Patient_ID AND v1.Recorded_At = v2.Latest_Record
    ) v ON p.Patient_ID = v.Patient_ID
    LEFT JOIN Patient_Incubator pi ON p.Patient_ID = pi.Patient_ID
    LEFT JOIN Incubators i ON pi.Incubator_ID = i.Incubator_ID
    ORDER BY p.Patient_ID ASC";


$vitals_result = $conn->query($vitals_sql);

// Fetch incubator conditions
$incubator_sql = "
    SELECT i.Model, i.Location, 
           COALESCE(ip.CO2_Level, 'N/A') AS CO2_Level, 
           COALESCE(ip.Temperature, 'N/A') AS Temperature, 
           COALESCE(ip.Humidity, 'N/A') AS Humidity, 
           ip.Recorded_At
    FROM Incubators i
    LEFT JOIN Incubator_Parameters ip ON i.Incubator_ID = ip.Incubator_ID
    ORDER BY i.Incubator_ID DESC";

$incubator_result = $conn->query($incubator_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NICU Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Welcome, <?= $_SESSION['username'] ?></h1>
    <a href="logout.php">Logout</a>

    <h2>Modify Parameters</h2>

<div style="margin-bottom: 20px;">
    <a href="manage_patients.php">Manage Patients</a>
    <a href="manage_vitals.php">Manage Patient Vitals</a>
    <a href="manage_incubators.php">Manage Incubators</a>
</div>

    <h2>Latest Patient Vitals & Assigned Incubators</h2>
    <table>
        <tr>
            <th>Name</th>
            <th>Oxygen Level (%)</th>
            <th>Weight (kg)</th>
            <th>Heartbeat (BPM)</th>
            <th>Blood pH</th>
            <th>Assigned Incubator</th>
            <th>Location</th>
            <th>Last Updated</th>
        </tr>
        <?php while ($row = $vitals_result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['First_Name'] . " " . $row['Last_Name'] ?></td>
            <td><?= $row['Oxygen_Level'] ?></td>
            <td><?= $row['Weight'] ?></td>
            <td><?= $row['Heartbeat'] ?></td>
            <td><?= $row['Blood_pH'] ?></td>
            <td>
                <?= $row['Incubator_ID'] ? "ID " . $row['Incubator_ID'] . " (" . $row['Model'] . ")" : "Not Assigned" ?>
            </td>
            <td><?= $row['Location'] ?: "N/A" ?></td>
            <td><?= $row['Recorded_At'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <h2>Latest Incubator Conditions</h2>
    <table>
        <tr>
            <th>Model</th>
            <th>Location</th>
            <th>CO2 Level (%)</th>
            <th>Temperature (°C)</th>
            <th>Humidity (%)</th>
            <th>Last Updated</th>
        </tr>
        <?php while ($row = $incubator_result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['Model'] ?></td>
            <td><?= $row['Location'] ?></td>
            <td><?= $row['CO2_Level'] ?></td>
            <td><?= $row['Temperature'] ?></td>
            <td><?= $row['Humidity'] ?></td>
            <td><?= $row['Recorded_At'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
