<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_config.php';

// Fetch all patient vitals
$vitals_sql = "SELECT v.Vital_ID, p.First_Name, p.Last_Name, v.Oxygen_Level, v.Weight, v.Heartbeat, v.Blood_pH, v.Recorded_At
               FROM Patient_Vitals v
               JOIN Patients p ON v.Patient_ID = p.Patient_ID
               ORDER BY v.Recorded_At DESC";
$vitals_result = $conn->query($vitals_sql);

// Fetch all patients for the dropdown
$patients_sql = "SELECT Patient_ID, First_Name, Last_Name FROM Patients";
$patients_result = $conn->query($patients_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Patient Vitals</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Manage Patient Vitals</h1>
    <a href="dashboard.php">Back to Dashboard</a>

    <h2>Add New Vital Record</h2>
<form action="add_vital.php" method="POST">
    <label>Patient:</label>
    <select name="patient_id" required>
        <?php while ($row = $patients_result->fetch_assoc()): ?>
            <option value="<?= $row['Patient_ID'] ?>"><?= $row['First_Name'] . " " . $row['Last_Name'] ?></option>
        <?php endwhile; ?>
    </select>

    <label>Oxygen Level (%):</label>
    <input type="number" step="0.1" name="oxygen_level" min="0" max="100" required>

    <label>Weight (kg):</label>
    <input type="number" step="0.1" name="weight" min="0" required>

    <label>Heartbeat (BPM):</label>
    <input type="number" name="heartbeat" min="0" required>

    <label>Blood pH:</label>
    <input type="number" step="0.01" name="blood_ph" min="6.8" max="7.8" required>

    <button type="submit">Add Vital Record</button>
</form>


    <h2>Patient Vitals List</h2>
    <table>
        <tr>
            <th>Patient</th>
            <th>Oxygen Level</th>
            <th>Weight</th>
            <th>Heartbeat</th>
            <th>Blood pH</th>
            <th>Recorded At</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $vitals_result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['First_Name'] . " " . $row['Last_Name'] ?></td>
            <td><?= $row['Oxygen_Level'] ?>%</td>
            <td><?= $row['Weight'] ?> kg</td>
            <td><?= $row['Heartbeat'] ?> BPM</td>
            <td><?= $row['Blood_pH'] ?></td>
            <td><?= $row['Recorded_At'] ?></td>
            <td>
                <a href="edit_vital.php?id=<?= $row['Vital_ID'] ?>">Edit</a>
                <a href="delete_vital.php?id=<?= $row['Vital_ID'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
