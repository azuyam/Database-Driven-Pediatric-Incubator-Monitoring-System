<?php
session_start();
include 'db_config.php';

if (!isset($_GET['id'])) {
    header("Location: manage_vitals.php");
    exit();
}

$vital_id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM Patient_Vitals WHERE Vital_ID = ?");
$stmt->bind_param("i", $vital_id);

if ($stmt->execute()) {
    header("Location: manage_vitals.php");
    exit();
} else {
    echo "Error deleting vital record.";
}
?>
