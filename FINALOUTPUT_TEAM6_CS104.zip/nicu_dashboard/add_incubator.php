<?php
session_start();
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $model = trim($_POST['model']);
    $manufacturer = trim($_POST['manufacturer']);
    $location = trim($_POST['location']);
    $co2_level = $_POST['co2_level'];
    $temperature = $_POST['temperature'];
    $humidity = $_POST['humidity'];

    // Validate incubator details
    if (empty($model) || empty($manufacturer) || empty($location)) {
        die("Error: Model, manufacturer, and location are required.");
    }

    // Validate CO2 Level (must be between 0 and 400 ppm)
    if (!is_numeric($co2_level) || $co2_level < 0 || $co2_level > 400) {
        die("Error: CO2 level must be between 0 ppm and 400 ppm.");
    }

    // Validate Temperature (must be between 25°C and 42°C)
    if (!is_numeric($temperature) || $temperature < 25 || $temperature > 42) {
        die("Error: Temperature must be between 25°C and 40°C.");
    }

    // Validate Humidity (must be between 30% and 80%)
    if (!is_numeric($humidity) || $humidity < 30 || $humidity > 80) {
        die("Error: Humidity must be between 30% and 80%.");
    }

    // Insert new incubator
    $stmt = $conn->prepare("INSERT INTO Incubators (Model, Manufacturer, Location) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $model, $manufacturer, $location);

    if ($stmt->execute()) {
        $incubator_id = $conn->insert_id;

        // Insert initial incubator parameters
        $param_stmt = $conn->prepare("INSERT INTO Incubator_Parameters (Incubator_ID, CO2_Level, Temperature, Humidity, Recorded_At) 
                                      VALUES (?, ?, ?, ?, NOW())");
        $param_stmt->bind_param("iddd", $incubator_id, $co2_level, $temperature, $humidity);
        $param_stmt->execute();
        $param_stmt->close();

        header("Location: manage_incubators.php");
        exit();
    } else {
        echo "Error adding incubator.";
    }

    $stmt->close();
}
?>
