<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_config.php';

// Fetch incubators along with their parameters
$incubators_sql = "SELECT i.Incubator_ID, i.Model, i.Manufacturer, i.Location, 
           COALESCE(ip.CO2_Level, 'N/A') AS CO2_Level, 
           COALESCE(ip.Temperature, 'N/A') AS Temperature, 
           COALESCE(ip.Humidity, 'N/A') AS Humidity 
    FROM Incubators i
    LEFT JOIN Incubator_Parameters ip ON i.Incubator_ID = ip.Incubator_ID
    ORDER BY i.Incubator_ID DESC";

$incubators_result = $conn->query($incubators_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Incubators</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Manage Incubators</h1>
    <a href="dashboard.php">Back to Dashboard</a>

<h2>Add New Incubator</h2>
<form action="add_incubator.php" method="POST">
    <label>Model:</label>
    <input type="text" name="model" required>

    <label>Manufacturer:</label>
    <input type="text" name="manufacturer" required>

    <label>Location:</label>
    <input type="text" name="location" required>

    <h3>Initial Conditions</h3>

    <label>CO2 Level (ppm):</label>
    <input type="number" step="0" name="co2_level" min="0" max="400" required>

    <label>Temperature (°C):</label>
    <input type="number" step="0.1" name="temperature" min="25" max="42" required>

    <label>Humidity (%):</label>
    <input type="number" step="0.1" name="humidity" min="30" max="80" required>

    <button type="submit">Add Incubator</button>
</form>



    <h2>Incubator List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Model</th>
            <th>Manufacturer</th>
            <th>Location</th>
            <th>CO2 Level (%)</th>
            <th>Temperature (°C)</th>
            <th>Humidity (%)</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $incubators_result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['Incubator_ID'] ?></td>
            <td><?= $row['Model'] ?></td>
            <td><?= $row['Manufacturer'] ?></td>
            <td><?= $row['Location'] ?></td>
            <td><?= $row['CO2_Level'] ?></td>
            <td><?= $row['Temperature'] ?></td>
            <td><?= $row['Humidity'] ?></td>
            <td>
                <a href="edit_incubator.php?id=<?= $row['Incubator_ID'] ?>">Edit</a>
                <a href="delete_incubator.php?id=<?= $row['Incubator_ID'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
