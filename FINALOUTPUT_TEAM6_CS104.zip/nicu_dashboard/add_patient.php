<?php
session_start();
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];

    $stmt = $conn->prepare("INSERT INTO Patients (First_Name, Last_Name) VALUES (?, ?)");
    $stmt->bind_param("ss", $first_name, $last_name);

    if ($stmt->execute()) {
        header("Location: manage_patients.php");
        exit();
    } else {
        echo "Error adding patient.";
    }

    $stmt->close();
}
?>
