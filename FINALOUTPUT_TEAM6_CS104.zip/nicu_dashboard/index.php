<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_config.php';

// Fetch incubator data
$incubator_sql = "SELECT i.Model, i.Location, ip.CO2_Level, ip.Temperature, ip.Humidity, ip.Recorded_At 
                  FROM Incubators i
                  JOIN Incubator_Parameters ip ON i.Incubator_ID = ip.Incubator_ID
                  ORDER BY ip.Recorded_At DESC
                  LIMIT 5";
$incubator_result = $conn->query($incubator_sql);

// Fetch patient vitals
$vitals_sql = "SELECT p.First_Name, p.Last_Name, v.Oxygen_Level, v.Weight, v.Heartbeat, v.Blood_pH, v.Recorded_At 
               FROM Patients p
               JOIN Patient_Vitals v ON p.Patient_ID = v.Patient_ID
               ORDER BY v.Recorded_At DESC
               LIMIT 5";
$vitals_result = $conn->query($vitals_sql);

// Fetch latest incubator data
$incubator_sql = "SELECT i.Model, i.Location, ip.CO2_Level, ip.Temperature, ip.Humidity, ip.Recorded_At 
                  FROM Incubators i
                  JOIN Incubator_Parameters ip ON i.Incubator_ID = ip.Incubator_ID
                  ORDER BY ip.Recorded_At DESC
                  LIMIT 5";
$incubator_result = $conn->query($incubator_sql);

// Fetch latest patient vitals
$vitals_sql = "SELECT p.First_Name, p.Last_Name, v.Oxygen_Level, v.Weight, v.Heartbeat, v.Blood_pH, v.Recorded_At 
               FROM Patients p
               JOIN Patient_Vitals v ON p.Patient_ID = v.Patient_ID
               ORDER BY v.Recorded_At DESC
               LIMIT 5";
$vitals_result = $conn->query($vitals_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NICU Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>NICU Monitoring Dashboard</h1>

    <h2>Latest Incubator Conditions</h2>
    <table>
        <tr>
            <th>Model</th>
            <th>Location</th>
            <th>CO2 Level (%)</th>
            <th>Temperature (°C)</th>
            <th>Humidity (%)</th>
            <th>Last Updated</th>
        </tr>
        <?php while ($row = $incubator_result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['Model'] ?></td>
            <td><?= $row['Location'] ?></td>
            <td><?= $row['CO2_Level'] ?></td>
            <td><?= $row['Temperature'] ?></td>
            <td><?= $row['Humidity'] ?></td>
            <td><?= $row['Recorded_At'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <h2>Latest Patient Vitals</h2>
    <table>
        <tr>
            <th>Name</th>
            <th>Oxygen Level (%)</th>
            <th>Weight (kg)</th>
            <th>Heartbeat (BPM)</th>
            <th>Blood pH</th>
            <th>Last Updated</th>
        </tr>
        <?php while ($row = $vitals_result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['First_Name'] . " " . $row['Last_Name'] ?></td>
            <td><?= $row['Oxygen_Level'] ?></td>
            <td><?= $row['Weight'] ?></td>
            <td><?= $row['Heartbeat'] ?></td>
            <td><?= $row['Blood_pH'] ?></td>
            <td><?= $row['Recorded_At'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <a href="login.php">Admin Login</a>
</body>
</html>
