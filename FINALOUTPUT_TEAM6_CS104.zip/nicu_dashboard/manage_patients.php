<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_config.php';

// Fetch all patients
$patients_sql = "SELECT p.Patient_ID, p.First_Name, p.Last_Name, 
                        COALESCE(i.Incubator_ID, 'Not Assigned') AS Incubator_ID, 
                        COALESCE(i.Model, 'N/A') AS Incubator_Model, 
                        COALESCE(i.Location, 'N/A') AS Location 
                 FROM Patients p
                 LEFT JOIN Patient_Incubator pi ON p.Patient_ID = pi.Patient_ID
                 LEFT JOIN Incubators i ON pi.Incubator_ID = i.Incubator_ID
                 ORDER BY p.Patient_ID ASC";

$patients_result = $conn->query($patients_sql);

// Debugging: Check if results are returned
if (isset($_GET['success']) && $_GET['success'] == 1) {
    echo "<p>Incubator assigned successfully!</p>";
} elseif (isset($_GET['error'])) {
    echo "<p>There was an error assigning the incubator.</p>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Patients</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Manage Patients</h1>
    <a href="dashboard.php">Back to Dashboard</a>

    <h2>Add New Patient</h2>
    <form action="add_patient.php" method="POST">
        <label>First Name:</label>
        <input type="text" name="first_name" required>

        <label>Last Name:</label>
        <input type="text" name="last_name" required>

        <button type="submit">Add Patient</button>
    </form>

    <h2>Patient List</h2>
    <table>
        <tr>
            <th>Patient ID</th>
            <th>Name</th>
            <th>Assigned Incubator</th>
            <th>Incubator Location</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $patients_result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['Patient_ID'] ?></td>
            <td><?= $row['First_Name'] . " " . $row['Last_Name'] ?></td>
            <td><?= $row['Incubator_ID'] !== 'Not Assigned' ? "ID " . $row['Incubator_ID'] . " (" . $row['Incubator_Model'] . ")" : "Not Assigned" ?></td>
            <td><?= $row['Location'] ?></td>
            <td>
                <a href="edit_patient.php?id=<?= $row['Patient_ID'] ?>">Edit</a>
                <a href="delete_patient.php?id=<?= $row['Patient_ID'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
                <a href="assign_incubator.php?id=<?= $row['Patient_ID'] ?>">Assign Incubator</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
