<?php
session_start();
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the patient ID and incubator ID from the form
    $patient_id = $_POST['patient_id'];
    $incubator_id = $_POST['incubator_id'];

    // Check if the incubator is already assigned
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Patient_Incubator WHERE Incubator_ID = ?");
    $stmt->bind_param("i", $incubator_id);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        // Handle the case where the incubator is already assigned
        header("Location: manage_patients.php?error=incubator_assigned");
        exit();
    }

    // Insert into the junction table to assign the incubator to the patient
    $stmt = $conn->prepare("INSERT INTO Patient_Incubator (Patient_ID, Incubator_ID) VALUES (?, ?)");
    
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("ii", $patient_id, $incubator_id);

    if ($stmt->execute()) {
        // Redirect back to manage_patients.php with a success message
        header("Location: manage_patients.php?success=1");
        exit();
    } else {
        // Handle error (optional)
        header("Location: manage_patients.php?error=1");
        exit();
    }

    $stmt->close();
} else {
    // If the request method is not POST, redirect to manage_patients.php
    header("Location: manage_patients.php");
    exit();
}

$conn->close();
?>