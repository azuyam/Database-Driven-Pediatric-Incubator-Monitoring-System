<?php
session_start();
include 'db_config.php';

if (!isset($_GET['id'])) {
    header("Location: manage_patients.php");
    exit();
}

$patient_id = $_GET['id'];

// Fetch patient details
$patient_sql = "SELECT * FROM Patients WHERE Patient_ID = ?";
$patient_stmt = $conn->prepare($patient_sql);
$patient_stmt->bind_param("i", $patient_id);
$patient_stmt->execute();
$patient_result = $patient_stmt->get_result();
$patient = $patient_result->fetch_assoc();

// Fetch available incubators
$incubators_sql = "SELECT Incubator_ID, Model, Location FROM Incubators";
$incubators_result = $conn->query($incubators_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Assign Incubator</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Assign Incubator to <?= htmlspecialchars($patient['First_Name'] . " " . $patient['Last_Name']) ?></h2>

        <form action="process_assign_incubator.php" method="POST">
            <input type="hidden" name="patient_id" value="<?= $patient_id ?>">

            <label>Select Incubator:</label>
            <select name="incubator_id" required>
                <?php while ($row = $incubators_result->fetch_assoc()): ?>
                    <option value="<?= $row['Incubator_ID'] ?>">ID <?= $row['Incubator_ID'] ?> - <?= htmlspecialchars($row['Model']) ?> (<?= htmlspecialchars($row['Location']) ?>)</option>
                <?php endwhile; ?>
            </select>

            <button type="submit">Assign</button>
        </form>

        <a href="manage_patients.php" class="back-button">Back</a>
    </div>
</body>
</html>
