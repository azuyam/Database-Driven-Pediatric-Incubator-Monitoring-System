<?php
session_start();
include 'db_config.php';

if (!isset($_GET['id'])) {
    header("Location: manage_incubators.php");
    exit();
}

$incubator_id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM Incubators WHERE Incubator_ID = ?");
$stmt->bind_param("i", $incubator_id);

if ($stmt->execute()) {
    header("Location: manage_incubators.php");
    exit();
} else {
    echo "Error deleting incubator.";
}
?>
