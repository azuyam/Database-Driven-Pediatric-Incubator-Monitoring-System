<?php
session_start();
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_id = $_POST['patient_id'];
    $oxygen_level = $_POST['oxygen_level'];
    $weight = $_POST['weight'];
    $heartbeat = $_POST['heartbeat'];
    $blood_ph = $_POST['blood_ph'];

    // Validate data
    if ($oxygen_level < 0 || $oxygen_level > 100 || $weight < 0 || $heartbeat < 0 || $blood_ph < 6.8 || $blood_ph > 7.8) {
        die("Invalid input values. Please check your data.");
    }

    $stmt = $conn->prepare("INSERT INTO Patient_Vitals (Patient_ID, Oxygen_Level, Weight, Heartbeat, Blood_pH) 
                            VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ididi", $patient_id, $oxygen_level, $weight, $heartbeat, $blood_ph);

    if ($stmt->execute()) {
        header("Location: manage_vitals.php");
        exit();
    } else {
        echo "Error adding vital record.";
    }

    $stmt->close();
}
?>
