<?php
session_start();
include 'db_config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage_incubators.php");
    exit();
}

$incubator_id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $model = $_POST['model'];
    $manufacturer = $_POST['manufacturer'];
    $location = $_POST['location'];
    $co2_level = $_POST['co2_level'];
    $temperature = $_POST['temperature'];
    $humidity = $_POST['humidity'];

    // Update Incubator details
// Assuming you have already established a connection to the database in $conn

// Prepare the SQL statement
$stmt = $conn->prepare("UPDATE Incubators I, Incubator_Parameters P SET I.Model = ?, I.Manufacturer = ?, I.Location = ?, P.co2_level = ?, P.temperature = ?, P.humidity = ? WHERE I.Incubator_ID = ? AND P.Incubator_ID = I.Incubator_ID");

// Check if the statement was prepared successfully
if ($stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}

// Bind parameters (assuming you have the values in variables)
$stmt->bind_param("sssssii", $model, $manufacturer, $location, $co2_level, $temperature, $humidity, $incubator_id);

// Execute the statement
if ($stmt->execute()) {
    // Redirect to manage_incubators.php after successful update
    header("Location: manage_incubators.php?success=1");
    exit(); // Make sure to call exit after header to stop further execution
} else {
    // Handle execution error
    die('Execute failed: ' . htmlspecialchars($stmt->error));
}

// Close the statement
$stmt->close();
    /* Update or insert parameters
    $stmt = $conn->prepare("
        INSERT INTO Incubator_Parameters (Incubator_ID, CO2_Level, Temperature, Humidity) 
        VALUES (?, ?, ?, ?) 
        ON DUPLICATE KEY UPDATE CO2_Level = VALUES(CO2_Level), Temperature = VALUES(Temperature), Humidity = VALUES(Humidity)");
    $stmt->bind_param("iddd", $incubator_id, $co2_level, $temperature, $humidity);
    $stmt->execute();
    $stmt->close();  */

}

// Fetch incubator details
$incubator_sql = "
    SELECT i.Model, i.Manufacturer, i.Location, 
           COALESCE(ip.CO2_Level, 'N/A') AS CO2_Level, 
           COALESCE(ip.Temperature, 'N/A') AS Temperature, 
           COALESCE(ip.Humidity, 'N/A') AS Humidity 
    FROM Incubators i
    LEFT JOIN Incubator_Parameters ip ON i.Incubator_ID = ip.Incubator_ID
    WHERE i.Incubator_ID = ?";
$incubator_stmt = $conn->prepare($incubator_sql);
$incubator_stmt->bind_param("i", $incubator_id);
$incubator_stmt->execute();
$incubator_result = $incubator_stmt->get_result();
$incubator = $incubator_result->fetch_assoc();

// If no incubator found, return error
if (!$incubator) {
    die("Incubator not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Incubator</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Edit Incubator</h2>
        <form method="POST">
            <label>Model:</label>
            <input type="text" name="model" value="<?= htmlspecialchars($incubator['Model']) ?>" required>

            <label>Manufacturer:</label>
            <input type="text" name="manufacturer" value="<?= htmlspecialchars($incubator['Manufacturer']) ?>" required>

            <label>Location:</label>
            <input type="text" name="location" value="<?= htmlspecialchars($incubator['Location']) ?>" required>

            <label>CO₂ Level (%):</label>
            <input type="number" step="0.1" name="co2_level" value="<?= ($incubator['CO2_Level'] !== 'N/A') ? $incubator['CO2_Level'] : '' ?>" placeholder="Enter CO₂ Level">

            <label>Temperature (°C):</label>
            <input type="number" step="0.1" name="temperature" value="<?= ($incubator['Temperature'] !== 'N/A') ? $incubator['Temperature'] : '' ?>" placeholder="Enter Temperature">

            <label>Humidity (%):</label>
            <input type="number" step="0.1" name="humidity" value="<?= ($incubator['Humidity'] !== 'N/A') ? $incubator['Humidity'] : '' ?>" placeholder="Enter Humidity">

            <button type="submit">Update</button>
        </form>
        <a href="manage_incubators.php" class="back-button">Back</a>
    </div>
</body>
</html>
